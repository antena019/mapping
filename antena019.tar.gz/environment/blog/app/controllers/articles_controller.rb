class ArticlesController < ApplicationController
    
    def gallery
        link_to gallery
    end
    
    def life
        link_to life
    end
    
    
    def new
        @article = Article.new
    end
    
    def create
        @article = Article.new(article_params)
        if @article.save
            redirect_to @article
        else
            render 'new'
        end
    end
    def show
        @article = Article.find(params[:id])
    end
    
    def index
        @article = Article.all
    end
    
private
    def article_params
        params.require(:article).permit(:title, :text)
    end
end
